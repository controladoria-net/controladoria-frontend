
  # Sistema de Análise de Documentos

  This is a code bundle for Sistema de Análise de Documentos. The original project is available at https://www.figma.com/design/XyYNMVrXdlnEskIe2rzzKp/Sistema-de-An%C3%A1lise-de-Documentos.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  